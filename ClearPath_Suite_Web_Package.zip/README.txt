CLEARPATH SUITE

Included:
- command-app-v2.html  -> Operations app
- profit-calculator.html -> Fixed profit calculator

Companion:
- ClearPath_Fugitive_Intelligence_Dashboard.zip -> Recovery intelligence dashboard

Fastest hosting:
1. Go to https://app.netlify.com/drop
2. Drag this ZIP onto the page
3. Netlify gives you a live URL

Then on iPhone:
Safari -> Share -> Add to Home Screen

Notes:
- Data stores locally in browser storage
- Use export/backup regularly
- If a browser preview makes buttons act dead, open in Safari or Chrome
